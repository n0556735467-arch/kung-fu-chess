// placeholder header for GameState
